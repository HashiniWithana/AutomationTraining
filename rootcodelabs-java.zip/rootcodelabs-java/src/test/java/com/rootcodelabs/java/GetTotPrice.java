package com.rootcodelabs.java;

public class GetTotPrice {
    public static void main(String[] args) {
        double price1=10.5;
        double price2=12.5;

             System.out.println ("Total is USD " + Double.sum(price1,price2));
    }



}
